
0.2.1 / 2016-07-27
==================

  * make wow mode work on all shells (#1) [@willmanduffy, @rauchg]

0.2.0 / 2016-07-27
==================

  * update hyperpower to work with 0.7.0+ :) [@rauchg]
  * "shake" option only enabled in "wow" mode now [@newyork-anthonyng]

0.1.3 / 2016-07-14
==================

  * add npm `keywords`

0.1.2 / 2016-07-13
==================

  * revert regexp

0.1.1 / 2016-07-13
==================

  * improve messages

0.1.0 / 2016-07-13
==================

  * initial release


